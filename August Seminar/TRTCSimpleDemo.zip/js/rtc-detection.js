/* global $ TRTC getOS getBrowser */
const DEVICE_TYPE_ENUM = {
  DESKTOP_WIN: 'desktop_win',
  DESKTOP_MAC: 'desktop_mac',
  MOBILE_ANDROID: 'mobile_android',
  MOBILE_IOS: 'mobile_ios'
};

const deviceType = getDeviceType();

/**
 * 获取当前设备类型
 */
function getDeviceType() {
  let deviceType;
  const osType = getOS().type;
  const osName = getOS().osName;
  switch (osType) {
    case 'desktop':
      deviceType =
        osName.indexOf('Mac OS') > -1 ? DEVICE_TYPE_ENUM.DESKTOP_MAC : DEVICE_TYPE_ENUM.DESKTOP_WIN;
      break;
    case 'mobile':
      deviceType = osName === 'iOS' ? DEVICE_TYPE_ENUM.MOBILE_IOS : DEVICE_TYPE_ENUM.MOBILE_ANDROID;
      break;
    default:
      break;
  }
  return deviceType;
}

/**
 * 根据设备类型获取支持的浏览器列表
 */
function getRecommendBrowserInfo() {
  let recommendBrowserInfo = '';
  switch (deviceType) {
    case DEVICE_TYPE_ENUM.DESKTOP_MAC:
      recommendBrowserInfo =
        ' Mac OS 장비를 사용하십시오. Chrome，Safari，Firefox 56+ 或 Edge 80+';
      break;
    case DEVICE_TYPE_ENUM.DESKTOP_WIN:
      recommendBrowserInfo = ' Windows 장비를 사용하십시오 Chrome, Firefox 56+ 或 Edge 80+';
      break;
    case DEVICE_TYPE_ENUM.MOBILE_ANDROID:
      recommendBrowserInfo = ' Android 장비를 사용하십시오 Chrome';
      break;
    case DEVICE_TYPE_ENUM.MOBILE_IOS:
      recommendBrowserInfo = ' iOS 장비를 사용하십시오Safari';
      break;
    default:
      recommendBrowserInfo = ' Chrome 최신 버전을 다운로드하는 것이 좋습니다.';
      break;
  }
  return recommendBrowserInfo;
}

/**
 * 是否是 桌面端 firefox 56+ 浏览器
 */
function isFirefoxM56() {
  if (deviceType === DEVICE_TYPE_ENUM.DESKTOP_WIN || deviceType === DEVICE_TYPE_ENUM.DESKTOP_MAC) {
    let browserInfo = getBrowser();
    if (browserInfo.browser === 'Firefox' && browserInfo.version >= '56') {
      return true;
    }
  }
  return false;
}

/**
 * rtc支持度检测
 */
async function rtcDetection() {
  // 当前浏览器不支持webRtc
  let checkResult = await TRTC.checkSystemRequirements();
  let deviceDetectionRemindInfo = '';
  let checkDetail = checkResult.detail;
  console.log('checkResult', checkResult.result, 'checkDetail', checkDetail);
  if (!checkResult.result) {
    // 通过TRTC获取详细不支持的信息
    $('#remind-info-container').show();

    // 查看链接是否符合webRtc限制
    if (
      location.protocol !== 'https:' &&
      location.hostname !== 'localhost' &&
      location.origin !== 'file://'
    ) {
      deviceDetectionRemindInfo =
        'webRTC는 다음과 같이 세 가지 유형의 주소를 지원합니다 :<br>' +
        '1) localhost 도메인 사용<br>' +
        '2) HTTPS 프로토콜 사용<br>' +
        '3) file : /// 프로토콜을 사용하여 열린 로컬 파일';
      $('#browser-remind').show();
      $('#remind-info').html(deviceDetectionRemindInfo);
      return false;
    }

    // 获取当前设备推荐的浏览器信息
    deviceDetectionRemindInfo = getRecommendBrowserInfo();

    console.log('isFirefoxM56', isFirefoxM56());
    if (isFirefoxM56() && !checkDetail.isH264Supported) {
      deviceDetectionRemindInfo =
        'Firefox는 아직 H264 인코딩 지원을 완료하지 않았습니다. 잠시 후 다시 시도하거나 다른 권장 브라우저를 사용하여 링크를여십시오.<br>' +
        deviceDetectionRemindInfo;
    }

    $('#browser-remind').show();
    $('#remind-info').html(deviceDetectionRemindInfo);

    return false;
  }
  return true;
}
